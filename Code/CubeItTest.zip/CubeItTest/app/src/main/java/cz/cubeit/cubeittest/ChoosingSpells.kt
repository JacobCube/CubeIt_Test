package cz.cubeit.cubeittest

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import cz.cubeit.cubeitfighttemplate.R
import kotlinx.android.synthetic.main.activity_choosing_spells.*
import kotlinx.android.synthetic.main.row_choosingspells.view.*
import java.sql.Types.NULL

class ChoosingSpells : AppCompatActivity() {
    private var learnedSpells = listOf(1,2,3,4,5,3)
    private var chosenSpells = arrayOf(5,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    private var energy = 100
    private var requiredEnergy = 0
    private var clickedSpell = 0

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choosing_spells)
        buttonChoose.visibility = View.INVISIBLE
        errorTextView.visibility = View.INVISIBLE

        choosing_listview.adapter = LearnedSpellsView(textLabel, textLevel, textDescription, textStats, learnedSpells, buttonChoose)
        chosen_listView.adapter = ChosenSpellsView(chosenSpells)

        buttonChoose.setOnClickListener{
            requiredEnergy = 0
            clickedSpell = (choosing_listview.adapter as LearnedSpellsView).getClickedSpell("clickedspell")
                for (i in 0..19) {
                    testTextView.text = ((energy+25*i) - requiredEnergy).toString()                   //testovací line
                    //if(requiredEnergy + spellSpec(clickedSpell, 3).toInt() <= energy) {
                        if (chosenSpells[i] == 0) {
                            if(requiredEnergy + spellSpec(clickedSpell, 3).toInt() <= (energy+25*i)){
                                errorTextView.visibility = View.INVISIBLE
                                chosenSpells[i] = clickedSpell
                                (chosen_listView.adapter as ChosenSpellsView).notifyDataSetChanged()
                                break
                            }else{
                                errorTextView.visibility = View.VISIBLE
                                errorTextView.text = "You would be too exhausted this round"
                                break
                            }
                        }else{
                            requiredEnergy += spellSpec(chosenSpells[i], 3).toInt()
                        }
                    /*} else {
                        errorTextView.visibility = View.VISIBLE
                        errorTextView.text = "You would be too exhausted this round"
                    }*/
                }
        }
    }

    private class LearnedSpellsView(var textViewLabel: TextView, var textViewLevel: TextView, var textViewDescription: TextView, var textViewStats: TextView, val learnedSpells: List<Int>, var buttonChoose: Button) : BaseAdapter() {

        var clickedSpellTemp = 0
        override fun getCount(): Int {
            return (learnedSpells.size/2+1)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View {
            val rowMain: View

            if (convertView == null) {
                val layoutInflater = LayoutInflater.from(viewGroup!!.context)
                rowMain = layoutInflater.inflate(R.layout.row_choosingspells, viewGroup, false)
                val viewHolder = ViewHolder(rowMain.button1, rowMain.button2)
                rowMain.tag = viewHolder
            } else {
                rowMain = convertView
            }
            val viewHolder = rowMain.tag as ViewHolder
            var positionIndex:Int
            try{
                viewHolder.button1.setBackgroundResource(getDrawable(learnedSpells[if(position==0){0}else{position*2}]))
                viewHolder.button2.setBackgroundResource(getDrawable(learnedSpells[if(position==0){1}else{position*2+1}]))

                if(learnedSpells[if(position==0){0}else{position*2}]!=0){
                    viewHolder.button1.setOnClickListener {
                        positionIndex = 0
                        positionIndex = if (position == 0) {
                            0
                        } else {
                            position * 2
                        }
                        textViewLabel.text = spellSpec(learnedSpells[positionIndex], 0)
                        textViewLevel.text = spellSpec(learnedSpells[positionIndex], 3)
                        textViewStats.text = spellSpec(learnedSpells[positionIndex], 2)
                        textViewDescription.text = spellSpec(learnedSpells[positionIndex], 4)
                        clickedSpellTemp = learnedSpells[if(position==0){0}else{position*2}]
                        buttonChoose.visibility = View.VISIBLE
                    }
                }else{
                    viewHolder.button1.isClickable = false
                }
            }catch(e:Exception){
                viewHolder.button1.isClickable = false
                viewHolder.button1.setBackgroundResource(getDrawable(0))
            }
            try{
                if(learnedSpells[if(position==0){1}else{position*2+1}]!=0){
                    viewHolder.button2.setOnClickListener {
                        positionIndex = 0
                        positionIndex = if (position == 0) {
                            1
                        } else {
                            position * 2 + 1
                        }
                        textViewLabel.text = spellSpec(learnedSpells[positionIndex], 0)
                        textViewLevel.text = spellSpec(learnedSpells[positionIndex], 3)
                        textViewStats.text = spellSpec(learnedSpells[positionIndex], 2)
                        textViewDescription.text = spellSpec(learnedSpells[positionIndex], 4)
                        clickedSpellTemp = learnedSpells[if(position==0){1}else{position*2+1}]
                        buttonChoose.visibility = View.VISIBLE
                    }
                }else{
                    viewHolder.button2.isClickable = false
                }
            }catch(e:Exception){
                viewHolder.button2.isClickable = false
                viewHolder.button2.setBackgroundResource(getDrawable(0))
            }
            return rowMain
        }

        private fun getDrawable(index:Int): Int {
            return(when(index) {
                1 -> R.drawable.basicattack
                2 -> R.drawable.shield
                3 -> R.drawable.firespell
                4 -> R.drawable.icespell
                5 -> R.drawable.windspell
                0 -> R.drawable.shield
                else -> NULL
            }
                    )
        }
        internal fun getClickedSpell(index:String): Int {
            return(when(index) {
                "clickedspell" -> clickedSpellTemp
                else -> NULL
            }
                    )
        }

        private class ViewHolder(val button1: TextView, val button2: TextView)

    }

    private class ChosenSpellsView(var chosenSpells: Array<Int>) : BaseAdapter() {

        override fun getCount(): Int {
            return 20
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View {
            val rowMain: View

            if (convertView == null) {
                val layoutInflater = LayoutInflater.from(viewGroup!!.context)
                rowMain = layoutInflater.inflate(R.layout.row_chosen_spells, viewGroup, false)
                val viewHolder = ViewHolder(rowMain.button1)
                rowMain.tag = viewHolder
            } else {
                rowMain = convertView
            }
            val viewHolder = rowMain.tag as ViewHolder

            viewHolder.button1.setBackgroundResource(getDrawable(chosenSpells[position]))
            viewHolder.button1.text = (position+1).toString()
            viewHolder.button1.gravity = Gravity.LEFT;           //pokouším se to vypisovat vedle talčítka, ale asi bude nejlepší řešení to přidat buďto do recycleru nebo na pevno vedle toho 20 textů

            viewHolder.button1.setOnClickListener {
                chosenSpells[position] = 0
                viewHolder.button1.setBackgroundResource(getDrawable(chosenSpells[position]))
            }

            return rowMain
        }

        private fun getDrawable(index:Int): Int {
            return(when(index) {
                1 -> R.drawable.basicattack
                2 -> R.drawable.shield
                3 -> R.drawable.firespell
                4 -> R.drawable.icespell
                5 -> R.drawable.windspell
                0 -> R.drawable.shield //empty slot
                else -> NULL
            }
                    )
        }

        private class ViewHolder(val button1: TextView)

    }
}


