package cz.cubeit.cubeitfighttemplate

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_choosing_spells.*
import kotlinx.android.synthetic.main.row_choosingspells.view.*
import java.lang.Math.round
import java.sql.Types.NULL
import android.view.Gravity
import android.text.method.TextKeyListener.clear



class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

    }
}