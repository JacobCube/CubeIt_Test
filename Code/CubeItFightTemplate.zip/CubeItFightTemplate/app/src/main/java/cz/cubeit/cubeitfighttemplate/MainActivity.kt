package cz.cubeit.cubeitfighttemplate

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

var playerHP = 1050
var enemyHP = 1050
const val playerAttack = 40
const val enemyAttack = 40

val playerSpells = arrayOf(3,4,5,0,0)
var enemySpellPreSet = arrayOf(1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2)     //data from server (Basci attack: 1, Block: 2, Spells: 3-5 - depending on the function "spellSpec")

fun Activity.toast(message:String, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, message, duration).show()
}

fun spellSpec(spellCode: Int, index: Int): String {                                        // going to be server function...or partly made from server
    val returnSpec = when(spellCode) {
        3 -> arrayOf("Fire Ball","@drawable/firespell", "20","level","description")
        4 -> arrayOf("Freezing touch", "@drawable/icespell","30","level","description")
        5 -> arrayOf("Wind hug", "@drawable/windspell","40","level","description")
        else -> arrayOf("null","null","null", "null", "null")
    }
    return returnSpec[index]
}
fun enemyAttack(roundCounter:Int):Int{
    return if (enemySpellPreSet[roundCounter] == 1) {
        enemyAttack
    } else {
        ((spellSpec(enemySpellPreSet[roundCounter], 2)).toDouble() * (enemyAttack.toDouble() / 10)).toInt()
    }
}

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        try {
            buttonSpell1.background = resources.getDrawable(resources.getIdentifier(spellSpec(playerSpells[0], 1), "drawable", packageName))
        } catch (e: Exception) {
            buttonSpell1.visibility = View.INVISIBLE
        }
        try {
            buttonSpell2.background = resources.getDrawable(resources.getIdentifier(spellSpec(playerSpells[1], 1), "drawable", packageName))
        } catch (e: Exception) {
            buttonSpell2.visibility = View.INVISIBLE
        }
        try {
            buttonSpell3.background = resources.getDrawable(resources.getIdentifier(spellSpec(playerSpells[2], 1), "drawable", packageName))
        } catch (e: Exception) {
            buttonSpell3.visibility = View.INVISIBLE
        }
        try {
            buttonSpell4.background = resources.getDrawable(resources.getIdentifier(spellSpec(playerSpells[3], 1), "drawable", packageName))
        } catch (e: Exception) {
            buttonSpell4.visibility = View.INVISIBLE
        }
        try {
            buttonSpell5.background = resources.getDrawable(resources.getIdentifier(spellSpec(playerSpells[4], 1), "drawable", packageName))
        } catch (e: Exception) {
            buttonSpell5.visibility = View.INVISIBLE
        }
        textPlayer.text = playerHP.toString()
        textEnemy.text = enemyHP.toString()

        var roundCounter = 0

        buttonAttack.setOnClickListener {
            try {
                if (enemySpellPreSet[roundCounter] == 0) {
                    roundCounter = 0
                }
            } catch (e: Exception) {
                roundCounter = 0
            }
            if (enemySpellPreSet[roundCounter] == 2) {
                enemyHP -= (playerAttack.toDouble() / 100 * 20).toInt()
                toast("Blocked!")
            } else {
                enemyHP -= playerAttack
            }
            textEnemy.text = enemyHP.toString()
            if (enemyHP <= 0) {
                toast("Enemy's dead, fight's over")
            }

            if (enemySpellPreSet[roundCounter] != 2) {
                playerHP -= enemyAttack(roundCounter)
            }
            textPlayer.text = playerHP.toString()
            if (playerHP <= 0) {
                toast("Player's dead, fight's over")
            }
            roundCounter++
        }
        buttonBlock.setOnClickListener {
            try {
                if (enemySpellPreSet[roundCounter] == 0) {
                    roundCounter = 0
                }
            } catch (e: Exception) {
                roundCounter = 0
            }
            if (enemySpellPreSet[roundCounter] != 2) {
                playerHP -= ((enemyAttack.toDouble()) / 100 * 20).toInt()
            }
            roundCounter++
            textEnemy.text = enemyHP.toString()
            textPlayer.text = playerHP.toString()
        }

            buttonSpell1.setOnClickListener {
                try {
                    if (enemySpellPreSet[roundCounter] == 0) {
                        roundCounter = 0
                    }
                } catch (e: Exception) {
                    roundCounter = 0
                }
                if (enemySpellPreSet[roundCounter] == 2) {
                    enemyHP -= (spellSpec(playerSpells[0], 2).toDouble() * (playerAttack.toDouble() / 10) / 100 * 20).toInt()
                    toast("Blocked!")
                } else {
                    enemyHP -= (spellSpec(playerSpells[0], 2).toDouble() * (playerAttack.toDouble() / 10)).toInt()
                }
                textEnemy.text = enemyHP.toString()
                if (enemyHP <= 0) {
                    toast("Enemy's dead, fight's over")
                }
                if (enemySpellPreSet[roundCounter] != 2) {
                    playerHP -= enemyAttack(roundCounter)
                }
                textPlayer.text = playerHP.toString()
                if (playerHP <= 0) {
                    toast("Player's dead, fight's over")
                }
                roundCounter++
            }

            buttonSpell2.setOnClickListener {
                try {
                    if (enemySpellPreSet[roundCounter] == 0) {
                        roundCounter = 0
                    }
                } catch (e: Exception) {
                    roundCounter = 0
                }
                if (enemySpellPreSet[roundCounter] == 2) {
                    enemyHP -= (spellSpec(playerSpells[1], 2).toDouble() * (playerAttack.toDouble() / 10) / 100 * 20).toInt()
                    toast("Blocked!")
                } else {
                    enemyHP -= (spellSpec(playerSpells[1], 2).toDouble() * (playerAttack.toDouble() / 10)).toInt()
                }
                textEnemy.text = enemyHP.toString()
                if (enemyHP <= 0) {
                    toast("Enemy's dead, fight's over")
                }
                if (enemySpellPreSet[roundCounter] != 2) {
                    playerHP -= enemyAttack(roundCounter)
                }
                textPlayer.text = playerHP.toString()
                if (playerHP <= 0) {
                    toast("Player's dead, fight's over")
                }
                roundCounter++
            }

            buttonSpell3.setOnClickListener {
                try {
                    if (enemySpellPreSet[roundCounter] == 0) {
                        roundCounter = 0
                    }
                } catch (e: Exception) {
                    roundCounter = 0
                }
                if (enemySpellPreSet[roundCounter] == 2) {
                    enemyHP -= (spellSpec(playerSpells[2], 2).toDouble() * (playerAttack.toDouble() / 10) / 100 * 20).toInt()
                    toast("Blocked!")
                } else {
                    enemyHP -= (spellSpec(playerSpells[2], 2).toDouble() * (playerAttack.toDouble() / 10)).toInt()
                }
                textEnemy.text = enemyHP.toString()
                if (enemyHP <= 0) {
                    toast("Enemy's dead, fight's over")
                }
                if (enemySpellPreSet[roundCounter] != 2) {
                    playerHP -= enemyAttack(roundCounter)
                }
                textPlayer.text = playerHP.toString()
                if (playerHP <= 0) {
                    toast("Player's dead, fight's over")
                }
                roundCounter++
            }

            buttonSpell4.setOnClickListener {
                try {
                    if (enemySpellPreSet[roundCounter] == 0) {
                        roundCounter = 0
                    }
                } catch (e: Exception) {
                    roundCounter = 0
                }
                if (enemySpellPreSet[roundCounter] == 2) {
                    enemyHP -= (spellSpec(playerSpells[3], 2).toDouble() * (playerAttack.toDouble() / 10) / 100 * 20).toInt()
                    toast("Blocked!")
                } else {
                    enemyHP -= (spellSpec(playerSpells[3], 2).toDouble() * (playerAttack.toDouble() / 10)).toInt()
                }
                textEnemy.text = enemyHP.toString()
                if (enemyHP <= 0) {
                    toast("Enemy's dead, fight's over")
                }
                if (enemySpellPreSet[roundCounter] != 2) {
                    playerHP -= enemyAttack(roundCounter)
                }
                textPlayer.text = playerHP.toString()
                if (playerHP <= 0) {
                    toast("Player's dead, fight's over")
                }
                roundCounter++
            }

            buttonSpell5.setOnClickListener {
                try {
                    if (enemySpellPreSet[roundCounter] == 0) {
                        roundCounter = 0
                    }
                } catch (e: Exception) {
                    roundCounter = 0
                }
                if (enemySpellPreSet[roundCounter] == 2) {
                    enemyHP -= (spellSpec(playerSpells[4], 2).toDouble() * (playerAttack.toDouble() / 10) / 100 * 20).toInt()
                    textEnemy.text = enemyHP.toString()
                    toast("Blocked!")
                } else {
                    enemyHP -= (spellSpec(playerSpells[4], 2).toDouble() * (playerAttack.toDouble() / 10)).toInt()
                }
                textEnemy.text = enemyHP.toString()
                if (enemyHP <= 0) {
                    toast("Enemy's dead, fight's over")
                }
                if (enemySpellPreSet[roundCounter] != 2) {
                    playerHP -= enemyAttack(roundCounter)
                }
                textPlayer.text = playerHP.toString()
                if (playerHP <= 0) {
                    toast("Player's dead, fight's over")
                }
                roundCounter++
            }
            val chooseSpell = findViewById<Button>(R.id.setUpSpells)
            chooseSpell.setOnClickListener{
                val intent = Intent(this, ChoosingSpells::class.java)
                startActivity(intent)
            }
    }
}