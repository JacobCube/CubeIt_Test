package cz.cubeit.cubeitfighttemplate

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_choosing_spells.*
import kotlinx.android.synthetic.main.row_choosingspells.view.*
import java.lang.Math.round
import java.sql.Types.NULL
import android.view.Gravity
import android.text.method.TextKeyListener.clear



class ChoosingSpells : AppCompatActivity() {
    private var learnedSpells = listOf(3,4,0,0,5,5)
    private val chosenSpells = arrayOf(5,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    private var clickedSpell = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choosing_spells)
        buttonChoose.visibility = View.INVISIBLE

        val listView = findViewById<ListView>(R.id.choosing_listview)

        choosing_listview.adapter = LearnedSpellsView(textLabel,textLevel,textDescription,textStats, learnedSpells, clickedSpell, buttonChoose)
        chosen_listView.adapter = ChosenSpellsView(chosenSpells)
        chosen_listView.adapter

        buttonChoose.setOnClickListener{
            for (i in 1..19) {
                if(chosenSpells[i] != 0){
                    chosenSpells[i] = clickedSpell
                    buttonChoose.text = chosenSpells[i].toString()
                    ChosenSpellsView(chosenSpells)
                    break
                }
            }
        }
    }

    private class LearnedSpellsView(var textViewLabel: TextView, var textViewLevel: TextView, var textViewDescription: TextView, var textViewStats: TextView, val learnedSpells: List<Int>, var clickedSpell:Int, var buttonChoose: Button) : BaseAdapter() {

        override fun getCount(): Int {
            return (learnedSpells.size/2+1)
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View {
            val rowMain: View

            if (convertView == null) {
                val layoutInflater = LayoutInflater.from(viewGroup!!.context)
                rowMain = layoutInflater.inflate(R.layout.row_choosingspells, viewGroup, false)
                val viewHolder = ViewHolder(rowMain.button1, rowMain.button2)
                rowMain.tag = viewHolder
            } else {
                rowMain = convertView
            }
            val viewHolder = rowMain.tag as ViewHolder
            try{
                viewHolder.button1.setBackgroundResource(getDrawable(learnedSpells[if(position==0){0}else{position*2}]))
                viewHolder.button2.setBackgroundResource(getDrawable(learnedSpells[if(position==0){1}else{position*2+1}]))

                if(learnedSpells[if(position==0){0}else{position*2}]!=0){
                    viewHolder.button1.setOnClickListener {
                        textViewLabel.text = spellSpec(learnedSpells[if(position==0){0}else{position*2}],0)
                        textViewLevel.text = spellSpec(learnedSpells[if(position==0){0}else{position*2}],3)
                        textViewStats.text = spellSpec(learnedSpells[if(position==0){0}else{position*2}],2)
                        textViewDescription.text = spellSpec(learnedSpells[if(position==0){0}else{position*2}],4)
                        clickedSpell = learnedSpells[if(position==0){0}else{position*2}]
                        buttonChoose.visibility = View.VISIBLE
                    }
                }else{
                    viewHolder.button1.isClickable = false
                }
            }catch(e:Exception){
                viewHolder.button1.isClickable = false
                viewHolder.button1.setBackgroundResource(getDrawable(0))
            }
            try{
                if(learnedSpells[if(position==0){1}else{position*2+1}]!=0){
                    viewHolder.button2.setOnClickListener {
                        textViewLabel.text = spellSpec(learnedSpells[if(position==0){1}else{position*2+1}],0)
                        textViewLevel.text = spellSpec(learnedSpells[if(position==0){1}else{position*2+1}],3)
                        textViewStats.text = spellSpec(learnedSpells[if(position==0){1}else{position*2+1}],2)
                        textViewDescription.text = spellSpec(learnedSpells[if(position==0){1}else{position*2+1}],4)
                        clickedSpell = learnedSpells[if(position==0){1}else{position*2+1}]
                        buttonChoose.visibility = View.VISIBLE
                    }
                }else{
                    viewHolder.button2.isClickable = false
                }
            }catch(e:Exception){
                viewHolder.button2.isClickable = false
                viewHolder.button2.setBackgroundResource(getDrawable(0))
            }
            return rowMain
        }

        private fun getDrawable(index:Int): Int {
            return(when(index) {
                3 -> R.drawable.firespell
                4 -> R.drawable.icespell
                5 -> R.drawable.windspell
                0 -> R.drawable.shield
                else -> NULL
            }
                    )
        }

        private class ViewHolder(val button1: TextView, val button2: TextView)

    }

    private class ChosenSpellsView(var chosenSpells: Array<Int>) : BaseAdapter() {

        override fun getCount(): Int {
            return 20
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        fun ChosenSpellsView(chsenSpells: Array<Int>) {
            this.chosenSpells = chsenSpells
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View {
            val rowMain: View

            if (convertView == null) {
                val layoutInflater = LayoutInflater.from(viewGroup!!.context)
                rowMain = layoutInflater.inflate(R.layout.row_chosen_spells, viewGroup, false)
                val viewHolder = ViewHolder(rowMain.button1)
                rowMain.tag = viewHolder
            } else {
                rowMain = convertView
            }
            val viewHolder = rowMain.tag as ViewHolder

            viewHolder.button1.setBackgroundResource(getDrawable(chosenSpells[position]))
            viewHolder.button1.text = (position+1).toString()
            viewHolder.button1.gravity = Gravity.LEFT;

            viewHolder.button1.setOnClickListener {
                chosenSpells[position] = 0
                viewHolder.button1.setBackgroundResource(getDrawable(chosenSpells[position]))
            }

            return rowMain
        }

        private fun getDrawable(index:Int): Int {
            return(when(index) {
                3 -> R.drawable.firespell
                4 -> R.drawable.icespell
                5 -> R.drawable.windspell
                0 -> R.drawable.shield //empty slot
                else -> NULL
            }
                    )
        }

        private class ViewHolder(val button1: TextView)

    }
}


